#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_NOM 50
#define MAX_MSG 200

// LES STRUCTURES UTILISEES
typedef struct Message {
    char contenu[MAX_MSG];
    time_t timestamp;
    struct Message *suiv;
} Message;

typedef struct Relation {
    int idUser;
    struct Relation *suiv;
} Relation;

typedef struct Utilisateur {
    int id;
    char nom[MAX_NOM];
    Relation *amis;
    Relation *abonnements;
    Message *publications;
    struct Utilisateur *gauche, *droite;
} Utilisateur;

// DECLARATION DES FONCTIONS 
Utilisateur* creerUtilisateur(int id, char *nom);
Utilisateur* insererABR(Utilisateur *racine, int id, char *nom);
Utilisateur* rechercherABR(Utilisateur *racine, int id);
Utilisateur* supprimerABR(Utilisateur *racine, int id);
void ajouterRelation(Relation **tete, int id);
int rechercherRelation(Relation *tete, int id);
void publierMessage(Utilisateur *user, char *msg);
void afficherTimeline(Utilisateur *racine, Utilisateur *user);
void sauvegarderUtilisateurs(Utilisateur *racine, FILE *f);
void sauvegarderRelations(Utilisateur *racine, FILE *f);
Utilisateur* chargerUtilisateurs(FILE *f);
void chargerRelations(Utilisateur *racine, FILE *f);
void afficherStatistiques(Utilisateur *racine);
void libererABR(Utilisateur *racine);
void menu();

//  FONCTIONS UTILISATEURS (AVEC ARBRE BINAIRE)
Utilisateur* creerUtilisateur(int id, char *nom) {
    Utilisateur *u = (Utilisateur*)malloc(sizeof(Utilisateur));
    u->id = id;
    strcpy(u->nom, nom);
    u->amis = NULL;
    u->abonnements = NULL;
    u->publications = NULL;
    u->gauche = u->droite = NULL;
    return u;
}

Utilisateur* insererABR(Utilisateur *racine, int id, char *nom) {
    if (racine == NULL) return creerUtilisateur(id, nom);
    if (id < racine->id)
        racine->gauche = insererABR(racine->gauche, id, nom);
    else if (id > racine->id)
        racine->droite = insererABR(racine->droite, id, nom);
    else
        printf("Utilisateur %d existe deja!\n", id);
    return racine;
}

Utilisateur* rechercherABR(Utilisateur *racine, int id) {
    if (racine == NULL || racine->id == id) return racine;
    if (id < racine->id)
        return rechercherABR(racine->gauche, id);
    return rechercherABR(racine->droite, id);
}

Utilisateur* trouverMin(Utilisateur *node) {
    while (node->gauche != NULL) node = node->gauche;
    return node;
}

Utilisateur* supprimerABR(Utilisateur *racine, int id) {
    if (racine == NULL) return NULL;
    if (id < racine->id)
        racine->gauche = supprimerABR(racine->gauche, id);
    else if (id > racine->id)
        racine->droite = supprimerABR(racine->droite, id);
    else {
        if (racine->gauche == NULL) {
            Utilisateur *temp = racine->droite;
            free(racine);
            return temp;
        } else if (racine->droite == NULL) {
            Utilisateur *temp = racine->gauche;
            free(racine);
            return temp;
        }
        Utilisateur *temp = trouverMin(racine->droite);
        racine->id = temp->id;
        strcpy(racine->nom, temp->nom);
        racine->droite = supprimerABR(racine->droite, temp->id);
    }
    return racine;
}

void afficherUtilisateurs(Utilisateur *racine) {
    if (racine != NULL) {
        afficherUtilisateurs(racine->gauche);
        printf("  [%d] %s\n", racine->id, racine->nom);
        afficherUtilisateurs(racine->droite);
    }
}

//  FONCTIONS RELATIONS(LISTE CHAINEE )
void ajouterRelation(Relation **tete, int id) {
    if (rechercherRelation(*tete, id)) {
        printf("Relation existe deja!\n");
        return;
    }
    Relation *nouv = (Relation*)malloc(sizeof(Relation));
    nouv->idUser = id;
    nouv->suiv = *tete;
    *tete = nouv;
}

int rechercherRelation(Relation *tete, int id) {
    while (tete != NULL) {
        if (tete->idUser == id) return 1;
        tete = tete->suiv;
    }
    return 0;
}

void afficherRelations(Relation *tete) {
    if (tete == NULL) {
        printf("  Aucune\n");
        return;
    }
    while (tete != NULL) {
        printf("  %d", tete->idUser);
        tete = tete->suiv;
        if (tete != NULL) printf(", ");
    }
    printf("\n");
}

// FONCTIONS PUBLICATIONS (LISTE CHAINEE)
void publierMessage(Utilisateur *user, char *msg) {
    Message *nouv = (Message*)malloc(sizeof(Message));
    strcpy(nouv->contenu, msg);
    nouv->timestamp = time(NULL);
    nouv->suiv = user->publications;
    user->publications = nouv;
}

void afficherMessages(Message *msgs, int limit) {
    int count = 0;
    while (msgs != NULL && count < limit) {
        printf("  - %s\n", msgs->contenu);
        msgs = msgs->suiv;
        count++;
    }
}

void afficherTimeline(Utilisateur *racine, Utilisateur *user) {
    printf("\n=== Timeline de %s ===\n", user->nom);
    printf("\nMes publications:\n");
    afficherMessages(user->publications, 5);
    
    printf("\nPublications des amis:\n");
    Relation *r = user->amis;
    while (r != NULL) {
        Utilisateur *ami = rechercherABR(racine, r->idUser);
        if (ami != NULL && ami->publications != NULL) {
            printf("\n  De %s:\n", ami->nom);
            afficherMessages(ami->publications, 3);
        }
        r = r->suiv;
    }
    
    printf("\nPublications des abonnements:\n");
    r = user->abonnements;
    while (r != NULL) {
        Utilisateur *abo = rechercherABR(racine, r->idUser);
        if (abo != NULL && abo->publications != NULL) {
            printf("\n  De %s:\n", abo->nom);
            afficherMessages(abo->publications, 2);
        }
        r = r->suiv;
    }
}

//  STATISTIQUES (Tâche supplémentaire) 
void compterUtilisateurs(Utilisateur *racine, int *total, int *actifs) {
    if (racine != NULL) {
        (*total)++;
        if (racine->publications != NULL) (*actifs)++;
        compterUtilisateurs(racine->gauche, total, actifs);
        compterUtilisateurs(racine->droite, total, actifs);
    }
}

void afficherStatistiques(Utilisateur *racine) {
    int total = 0, actifs = 0;
    compterUtilisateurs(racine, &total, &actifs);
    printf("\n=== STATISTIQUES DU RESEAU ===\n");
    printf("Total utilisateurs: %d\n", total);
    printf("Utilisateurs actifs: %d\n", actifs);
    printf("Taux d'activite: %.1f%%\n", total > 0 ? (actifs*100.0/total) : 0);
}

//  PERSISTANCE DES DONNEES (LECTURE/ECRITURE FICHIERS)
void sauvegarderUtilisateurs(Utilisateur *racine, FILE *f) {
    if (racine != NULL) {
        fwrite(&racine->id, sizeof(int), 1, f);
        fwrite(racine->nom, sizeof(char), MAX_NOM, f);
        sauvegarderUtilisateurs(racine->gauche, f);
        sauvegarderUtilisateurs(racine->droite, f);
    }
}

void sauvegarderRelations(Utilisateur *racine, FILE *f) {
    if (racine != NULL) {
        fprintf(f, "%d:", racine->id);
        Relation *r = racine->amis;
        while (r != NULL) {
            fprintf(f, "A%d,", r->idUser);
            r = r->suiv;
        }
        r = racine->abonnements;
        while (r != NULL) {
            fprintf(f, "B%d,", r->idUser);
            r = r->suiv;
        }
        fprintf(f, "\n");
        sauvegarderRelations(racine->gauche, f);
        sauvegarderRelations(racine->droite, f);
    }
}

Utilisateur* chargerUtilisateurs(FILE *f) {
    Utilisateur *racine = NULL;
    int id;
    char nom[MAX_NOM];
    while (fread(&id, sizeof(int), 1, f) == 1) {
        fread(nom, sizeof(char), MAX_NOM, f);
        racine = insererABR(racine, id, nom);
    }
    return racine;
}

void chargerRelations(Utilisateur *racine, FILE *f) {
    char ligne[500];
    while (fgets(ligne, sizeof(ligne), f)) {
        int userId;
        sscanf(ligne, "%d:", &userId);
        Utilisateur *user = rechercherABR(racine, userId);
        if (user == NULL) continue;
        
        char *token = strtok(ligne + strlen(ligne) - strlen(strchr(ligne, ':')), ",");
        while (token != NULL) {
            if (token[0] == 'A')
                ajouterRelation(&user->amis, atoi(token + 1));
            else if (token[0] == 'B')
                ajouterRelation(&user->abonnements, atoi(token + 1));
            token = strtok(NULL, ",");
        }
    }
}

void sauvegarderDonnees(Utilisateur *racine) {
    FILE *f = fopen("utilisateurs.bin", "wb");
    if (f) {
        sauvegarderUtilisateurs(racine, f);
        fclose(f);
        printf("Utilisateurs sauvegardes!\n");
    }
    
    f = fopen("relations.txt", "w");
    if (f) {
        sauvegarderRelations(racine, f);
        fclose(f);
        printf("Relations sauvegardees!\n");
    }
}

Utilisateur* chargerDonnees() {
    Utilisateur *racine = NULL;
    FILE *f = fopen("utilisateurs.bin", "rb");
    if (f) {
        racine = chargerUtilisateurs(f);
        fclose(f);
        printf("Utilisateurs charges!\n");
    }
    
    f = fopen("relations.txt", "r");
    if (f && racine != NULL) {
        chargerRelations(racine, f);
        fclose(f);
        printf("Relations chargees!\n");
    }
    return racine;
}

// LIBERATION MEMOIRE
void libererRelations(Relation *tete) {
    while (tete != NULL) {
        Relation *temp = tete;
        tete = tete->suiv;
        free(temp);
    }
}

void libererMessages(Message *tete) {
    while (tete != NULL) {
        Message *temp = tete;
        tete = tete->suiv;
        free(temp);
    }
}

void libererABR(Utilisateur *racine) {
    if (racine != NULL) {
        libererABR(racine->gauche);
        libererABR(racine->droite);
        libererRelations(racine->amis);
        libererRelations(racine->abonnements);
        libererMessages(racine->publications);
        free(racine);
    }
}

// MENU
void menu() {
    printf("\n========== RESEAU SOCIAL SNS ==========\n");
    printf("1. Ajouter utilisateur\n");
    printf("2. Supprimer utilisateur\n");
    printf("3. Afficher utilisateurs\n");
    printf("4. Ajouter ami\n");
    printf("5. Ajouter abonnement\n");
    printf("6. Afficher profil\n");
    printf("7. Publier message\n");
    printf("8. Voir timeline\n");
    printf("9. Statistiques\n");
    printf("10. Sauvegarder\n");
    printf("0. Quitter\n");
    printf("=======================================\n");
    printf("Choix: ");
}

//  MAIN PROGRAMME PRINCIPAL
int main() {
    Utilisateur *racine = chargerDonnees();
    int choix, id, id2;
    char nom[MAX_NOM], msg[MAX_MSG];
    
    while (1) {
        menu();
        scanf("%d", &choix);
        getchar();
        
        switch (choix) {
            case 1:
                printf("ID: "); scanf("%d", &id);
                getchar();
                printf("Nom: "); fgets(nom, MAX_NOM, stdin);
                nom[strcspn(nom, "\n")] = 0;
                racine = insererABR(racine, id, nom);
                printf("Utilisateur ajoute!\n");
                break;
                
            case 2:
                printf("ID a supprimer: "); scanf("%d", &id);
                racine = supprimerABR(racine, id);
                printf("Utilisateur supprime!\n");
                break;
                
            case 3:
                printf("\n=== UTILISATEURS ===\n");
                afficherUtilisateurs(racine);
                break;
                
            case 4:
                printf("Votre ID: "); scanf("%d", &id);
                printf("ID ami: "); scanf("%d", &id2);
                Utilisateur *u1 = rechercherABR(racine, id);
                if (u1 && rechercherABR(racine, id2)) {
                    ajouterRelation(&u1->amis, id2);
                    printf("Ami ajoute!\n");
                } else printf("Utilisateur introuvable!\n");
                break;
                
            case 5:
                printf("Votre ID: "); scanf("%d", &id);
                printf("ID abonnement: "); scanf("%d", &id2);
                Utilisateur *u2 = rechercherABR(racine, id);
                if (u2 && rechercherABR(racine, id2)) {
                    ajouterRelation(&u2->abonnements, id2);
                    printf("Abonnement ajoute!\n");
                } else printf("Utilisateur introuvable!\n");
                break;
                
            case 6:
                printf("ID: "); scanf("%d", &id);
                Utilisateur *u3 = rechercherABR(racine, id);
                if (u3) {
                    printf("\n=== PROFIL ===\n");
                    printf("ID: %d\nNom: %s\n", u3->id, u3->nom);
                    printf("Amis:\n"); afficherRelations(u3->amis);
                    printf("Abonnements:\n"); afficherRelations(u3->abonnements);
                } else printf("Utilisateur introuvable!\n");
                break;
                
            case 7:
                printf("Votre ID: "); scanf("%d", &id);
                getchar();
                Utilisateur *u4 = rechercherABR(racine, id);
                if (u4) {
                    printf("Message: "); fgets(msg, MAX_MSG, stdin);
                    msg[strcspn(msg, "\n")] = 0;
                    publierMessage(u4, msg);
                    printf("Message publie!\n");
                } else printf("Utilisateur introuvable!\n");
                break;
                
            case 8:
                printf("Votre ID: "); scanf("%d", &id);
                Utilisateur *u5 = rechercherABR(racine, id);
                if (u5) afficherTimeline(racine, u5);
                else printf("Utilisateur introuvable!\n");
                break;
                
            case 9:
                afficherStatistiques(racine);
                break;
                
            case 10:
                sauvegarderDonnees(racine);
                break;
                
            case 0:
                sauvegarderDonnees(racine);
                libererABR(racine);
                printf("Au revoir!\n");
                return 0;
                
            default:
                printf("Choix invalide!\n");
        }
    }
    return 0;
}